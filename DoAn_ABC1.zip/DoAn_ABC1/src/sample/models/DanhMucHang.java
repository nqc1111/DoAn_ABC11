package sample.models;

public class DanhMucHang {
    private int id_dm;
    private String ten_dm;
    private String bieutuong_dm;


    public int getId_dm() {
        return id_dm;
    }

    public void setId_dm(int id_dm) {
        this.id_dm = id_dm;
    }

    public String getTen_dm() {
        return ten_dm;
    }

    public void setTen_dm(String ten_dm) {
        this.ten_dm = ten_dm;
    }

    public String getBieutuong_dm() {
        return bieutuong_dm;
    }

    public void setBieutuong_dm(String bieutuong_dm) {
        this.bieutuong_dm = bieutuong_dm;
    }

    public DanhMucHang(int id_dm, String ten_dm, String bieutuong_dm) {
        this.id_dm = id_dm;
        this.ten_dm = ten_dm;
        this.bieutuong_dm = bieutuong_dm;
    }

    @Override
    public String toString() {
        return "DanhMucHang{" +
                "id_dm=" + id_dm +
                ", ten_dm='" + ten_dm + '\'' +
                ", bieutuong_dm='" + bieutuong_dm + '\'' +
                '}';
    }
}
