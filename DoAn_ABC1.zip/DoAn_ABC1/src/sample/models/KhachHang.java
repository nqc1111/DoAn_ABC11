package sample.models;

import java.util.Date;

public class KhachHang {
    private int id_kh;
    private String ten_kh;
    private Date ntns_kh;
    private String diachi_kh;
    private String sdt_kh;
    private boolean gt_kh;


    public int getId_kh() {
        return id_kh;
    }

    public void setId_kh(int id_kh) {
        this.id_kh = id_kh;
    }

    public String getTen_kh() {
        return ten_kh;
    }

    public void setTen_kh(String ten_kh) {
        this.ten_kh = ten_kh;
    }

    public Date getNtns_kh() {
        return ntns_kh;
    }

    public void setNtns_kh(Date ntns_kh) {
        this.ntns_kh = ntns_kh;
    }

    public String getDiachi_kh() {
        return diachi_kh;
    }

    public void setDiachi_kh(String diachi_kh) {
        this.diachi_kh = diachi_kh;
    }

    public String getSdt_kh() {
        return sdt_kh;
    }

    public void setSdt_kh(String sdt_kh) {
        this.sdt_kh = sdt_kh;
    }

    public boolean isGt_kh() {
        return gt_kh;
    }

    public void setGt_kh(boolean gt_kh) {
        this.gt_kh = gt_kh;
    }

    public KhachHang(int id_kh, String ten_kh, Date ntns_kh, String diachi_kh, String sdt_kh, boolean gt_kh) {
        this.id_kh = id_kh;
        this.ten_kh = ten_kh;
        this.ntns_kh = ntns_kh;
        this.diachi_kh = diachi_kh;
        this.sdt_kh = sdt_kh;
        this.gt_kh = gt_kh;
    }

    @Override
    public String toString() {
        return "KhachHang{" +
                "id_kh=" + id_kh +
                ", ten_kh='" + ten_kh + '\'' +
                ", ntns_kh=" + ntns_kh +
                ", diachi_kh='" + diachi_kh + '\'' +
                ", sdt_kh='" + sdt_kh + '\'' +
                ", gt_kh=" + gt_kh +
                '}';
    }
}
